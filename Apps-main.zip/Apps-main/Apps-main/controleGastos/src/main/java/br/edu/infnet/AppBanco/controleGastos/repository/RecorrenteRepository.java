package br.edu.infnet.AppBanco.controleGastos.repository;


import br.edu.infnet.AppBanco.controleGastos.model.Recorrente;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
@Repository
public interface RecorrenteRepository extends CrudRepository<Recorrente, Integer> {
    Optional<Recorrente> findById(Integer integer);

}
